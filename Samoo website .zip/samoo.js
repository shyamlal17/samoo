const container = document.getElementById("container");
const signupForm = document.getElementById("signupForm");
const loginForm = document.getElementById("loginForm");
const goLogin = document.getElementById("goLogin");
const title = document.getElementById("switchTitle");

/* signup → login */
signupForm.addEventListener("submit", e => {
  e.preventDefault();
  container.classList.add("show-login");
});

/* ## click */
title.addEventListener("click", () => {
  container.classList.add("show-login");
});

/* already account */
goLogin.addEventListener("click", () => {
  container.classList.add("show-login");
});

/* login success */
loginForm.addEventListener("submit", e => {
  e.preventDefault();
  window.location.href = "samoo1.html";
});






function h2(html2) {
  window.open('new.html');
  // Tab to edit
}
function facebook() {
  // Tab to edit
  window.open(href='https://www.facebook.com/shyamlalsahajee.17')
}
function tiktok() {
  // Tab to edit
  window.open(href='https://www.tiktok.com/@shyamlalsahajee?')
}
function email() {
  // Tab to edit
  window.open(href = 'mailto:shyamlalsahajee450@gmail.com')
}