let currentGallery = 0;
let currentIndex = 0;
const galleries = document.querySelectorAll('.gallery');

function openGallery(index) {
  galleries.forEach((g, i) => {
    g.style.display = (i === index) ? 'grid' : 'none';
  });
  currentGallery = index;
}

// Lightbox
function openLightbox(index) {
  currentIndex = index;
  document.getElementById('lightbox').style.display = 'flex';
  showLightbox();
}

function closeLightbox() {
  document.getElementById('lightbox').style.display = 'none';
}

function changeSlide(n) {
  const imgs = galleries[currentGallery].querySelectorAll('img');
  currentIndex += n;
  if (currentIndex < 0) currentIndex = imgs.length - 1;
  if (currentIndex >= imgs.length) currentIndex = 0;
  showLightbox();
}

function showLightbox() {
  const imgs = galleries[currentGallery].querySelectorAll('img');
  document.getElementById('lightbox-img').src = imgs[currentIndex].src;
}
function email() {
  // Tab to edit
  window.open(href= 'mailto:shyamlalsahajee450@gmail.com')
}
function facebook(){
  
  window.open(href="https://www.facebook.com/shyamlalsahajee.17")
}
function tiktok() {
  
  window.open(href = "https://www.tiktok.com/@shyamlalsahajee")
}
function call() {
  
  window.open(href = "tel:01718439315")
}
function home() {
  // Tab to edit
  window.open(href='https://e-laeltd.com/')
}